# Creates 5 branches off main, each engineered to land at a specific DevPulse risk level,
# and pushes them. You then open the PRs in the GitHub UI (links are printed at the end).
# Run 01-setup-base.ps1 first. Start the tunnel + DevPulse BEFORE opening the PRs.
# Budget mode (default): 4 PRs -> only PR 3 (MEDIUM) and PR 4 (HIGH) can call the AI.
# Add -Full to also create PR 5 (CRITICAL), a third AI call.
param([switch]$Full)
$ErrorActionPreference = 'Stop'
$work = Join-Path $PSScriptRoot 'work'
$web = 'https://github.com/abhisriv25/devpulse-test-repo'
Set-Location $work

function Git { & git.exe @args; if ($LASTEXITCODE -ne 0) { throw "git $($args -join ' ') failed" } }
function Utf8 { param($Path, $Text) [IO.File]::WriteAllText((Join-Path $work $Path), $Text, (New-Object Text.UTF8Encoding $false)) }
function NewBranch { param($Name) Git checkout main; Git checkout -B $Name }
function Ship { param($Name, $Msg) Git add -A; Git commit -m $Msg; Git push -f -u origin $Name }

# 1) LOW: docs-only tweak (only the "no test files" rule fires: 15 pts)
NewBranch 'pr-1-docs-tweak'
Add-Content README.md "`nSee docs/testing-policy.md for how we test."
Ship 'pr-1-docs-tweak' 'Docs: link testing policy from README'

# 2) LOW, tests included: nothing fires (0 pts). Shows "tests present" passing.
NewBranch 'pr-2-feature-with-tests'
Add-Content src/utils/format.js "`nexport function initials(first, last) {`n  return (first.charAt(0) + last.charAt(0)).toUpperCase();`n}"
Add-Content tests/format.test.js "`ntest('initials', () => {`n  assert.equal(initials('ada', 'lovelace'), 'AL');`n});"
(Get-Content tests/format.test.js) -replace 'import \{ formatName \}', 'import { formatName, initials }' | Set-Content tests/format.test.js
Ship 'pr-2-feature-with-tests' 'Add initials helper with test'

# 3) MEDIUM: new dependency + source change, no tests (10 + 15 = 25 pts)
NewBranch 'pr-3-new-dependency'
$pkg = Get-Content package.json -Raw
$pkg = $pkg -replace '"dependencies": \{\}', "`"dependencies`": {`n    `"dayjs`": `"^1.11.10`"`n  }"
Utf8 'package.json' $pkg
Add-Content src/index.js "`nexport const startedAt = new Date().toISOString();"
Ship 'pr-3-new-dependency' 'Add dayjs for date formatting'

# 4) HIGH: auth change + migration, no tests (20 + 15 + 15 = 50 pts)
NewBranch 'pr-4-auth-and-migration'
Utf8 'src/auth/login.js' @'
const USERS = new Map([["ada", "correct horse"]]);
const attempts = new Map();

export function login(username, password) {
  const count = (attempts.get(username) ?? 0) + 1;
  attempts.set(username, count);
  if (count > 5) {
    return { ok: false, reason: "rate_limited" };
  }
  const expected = USERS.get(username);
  if (!expected || expected !== password) {
    return { ok: false };
  }
  attempts.delete(username);
  return { ok: true, sessionDays: 7 };
}
'@
Utf8 'migrations/002_add_sessions.sql' @'
-- Rollback: DROP TABLE sessions;
CREATE TABLE sessions (
  id BIGSERIAL PRIMARY KEY,
  user_id BIGINT NOT NULL REFERENCES users(id),
  token_hash TEXT NOT NULL,
  expires_at TIMESTAMPTZ NOT NULL
);
'@
Ship 'pr-4-auth-and-migration' 'Rate limit logins and add sessions table'

# 5) CRITICAL: big change across auth, config, migration, dependency, no tests (~80 pts)
if ($Full) {
NewBranch 'pr-5-big-risky-change'
$lines = New-Object System.Collections.Generic.List[string]
$lines.Add('// Token store (generated for the demo). Large on purpose so the diff-size rule fires.')
$lines.Add('export const TOKENS = new Map();')
for ($i = 1; $i -le 260; $i++) {
  $lines.Add("export function issueToken$i(userId) {")
  $lines.Add("  const token = ``t$i-`${userId}-`${Date.now()}``;")
  $lines.Add("  TOKENS.set(token, userId);")
  $lines.Add("  return token;")
  $lines.Add("}")
}
Utf8 'src/auth/token-store.js' (($lines -join "`n") + "`n")
Add-Content config.yml "token:`n  rotate_hours: 12"
Utf8 'migrations/003_add_tokens.sql' "-- Rollback: DROP TABLE tokens;`nCREATE TABLE tokens (id BIGSERIAL PRIMARY KEY, token TEXT NOT NULL, user_id BIGINT NOT NULL);`n"
$pkg = Get-Content package.json -Raw
$pkg = $pkg -replace '"private": true,', "`"private`": true,`n  `"description`": `"token rework`","
Utf8 'package.json' $pkg
Ship 'pr-5-big-risky-change' 'Rework token handling'
}

Git checkout main
Write-Host "`nBranches pushed. Open each PR here:" -ForegroundColor Green
$branches = @('pr-1-docs-tweak','pr-2-feature-with-tests','pr-3-new-dependency','pr-4-auth-and-migration')
if ($Full) { $branches += 'pr-5-big-risky-change' }
foreach ($b in $branches) {
  Write-Host "  $web/compare/main...$b`?expand=1"
}
