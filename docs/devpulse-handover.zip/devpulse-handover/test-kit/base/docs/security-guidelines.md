# Security Guidelines

## Changes to authentication code

Any change under `src/auth/` is security-sensitive. It requires review from two
engineers, one of whom must be on the security team. Authentication changes must not
be merged on a Friday or before a release freeze.

## Session handling

Sessions must expire after 7 days and be invalidated on logout. Never log session
tokens or passwords. Tokens must be stored hashed, never in plain text.

## Configuration and secrets

`config.yml` must never contain real secrets. Secrets are injected through environment
variables. A pull request that edits `config.yml` needs a second reviewer to confirm no
credential was added.

## Password rules

Passwords are compared with a constant-time function. Login attempts are rate limited
to 5 per minute per account.
