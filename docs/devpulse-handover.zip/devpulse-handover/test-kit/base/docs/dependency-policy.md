# Dependency Policy

## Adding or upgrading a dependency

- Check the license. Only MIT, Apache-2.0 and BSD licenses are allowed without legal review.
- Prefer the standard library or an existing dependency over adding a new one.
- Pin versions and commit the lockfile in the same pull request.
- A new dependency must be justified in the pull request description: what it does, why
  we need it, and what alternatives were considered.

## Review

Dependency changes need one reviewer who checks the package's maintenance status and
known vulnerabilities (`npm audit`) before approval.
