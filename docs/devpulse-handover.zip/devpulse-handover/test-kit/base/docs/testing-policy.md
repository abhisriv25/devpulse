# Testing Policy

- Every change to code under `src/` must include or update a test under `tests/`.
- Bug fixes must include a test that fails before the fix and passes after it.
- Pull requests that change behaviour without touching tests will be asked to add them.
- Large pull requests (more than 500 changed lines) should be split into smaller ones
  unless they are generated code.

## Running tests

```
npm test
```
