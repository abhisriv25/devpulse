# Database Migration Policy

## Rules

- Every schema change ships as a numbered file in `migrations/`.
- Migrations must be backward compatible: the previous app version must keep working
  while the migration runs. Add columns as nullable first, backfill, then add constraints
  in a later release.
- Never drop a column or table in the same release that stops using it.
- Migrations that touch tables with more than 1 million rows must be reviewed by the
  database owner and tested against a production-sized copy.

## Rollback

Each migration must include a documented rollback step in its header comment.

## Review

A migration pull request needs sign-off from the database owner. Do not combine a
migration with unrelated application changes in one pull request.
