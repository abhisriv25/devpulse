# Architecture

The service is a small Node.js app.

## Components

- **Login module (`src/auth/login.js`)** verifies credentials and creates sessions.
- **Formatting helpers (`src/utils/format.js`)** shared by every response.
- **Config (`config.yml`)** holds non-secret runtime settings such as session lifetime.
- **Database** is PostgreSQL. Schema changes are applied from `migrations/`.

## Release process

Releases are cut weekly. Security-sensitive or migration changes must be merged at least
one day before the release cut so they can bake in staging.
