export function formatName(first, last) {
  return `${capitalize(first)} ${capitalize(last)}`;
}

function capitalize(word) {
  return word.charAt(0).toUpperCase() + word.slice(1);
}
