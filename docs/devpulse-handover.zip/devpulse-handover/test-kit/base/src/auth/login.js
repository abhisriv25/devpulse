const USERS = new Map([["ada", "correct horse"]]);

export function login(username, password) {
  const expected = USERS.get(username);
  if (!expected || expected !== password) {
    return { ok: false };
  }
  return { ok: true, sessionDays: 7 };
}
