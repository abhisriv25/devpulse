import { formatName } from "./utils/format.js";
import { login } from "./auth/login.js";

export function main() {
  console.log(formatName("ada", "lovelace"));
  return login("ada", "correct horse");
}
