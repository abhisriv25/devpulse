# devpulse-test-repo

A small sample service used to demo DevPulse. It has a login module, a formatting
helper, a config file and database migrations, so pull requests against it can
trigger every DevPulse risk rule.

Engineering rules for this repo live in [`docs/`](docs/). Read them before opening a PR.

## Layout

- `src/auth/` – login and session handling (security-sensitive)
- `src/utils/` – formatting helpers
- `migrations/` – SQL migrations
- `config.yml` – runtime configuration (security-sensitive)
- `tests/` – unit tests
