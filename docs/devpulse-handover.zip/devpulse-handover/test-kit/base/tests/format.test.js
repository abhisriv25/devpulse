import test from "node:test";
import assert from "node:assert/strict";
import { formatName } from "../src/utils/format.js";

test("formatName capitalizes both parts", () => {
  assert.equal(formatName("ada", "lovelace"), "Ada Lovelace");
});
